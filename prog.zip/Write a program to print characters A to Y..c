#include <stdio.h>
main()
{
 char c;
 for (c = 'A';c <= 'Z';++c)
 {
 printf("\n\t%c",c);
 }
 getch();
 return 0;
}
